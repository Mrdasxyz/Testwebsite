from fastapi.responses import HTMLResponse
from fastapi import Depends
from sqlalchemy.orm import Session
from fastapi.templating import Jinja2Templates
from fastapi import FastAPI, Request, Form, HTTPException
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table
from sqlalchemy.orm import declarative_base, Session

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Aiven Cloud MySQL credentials
db_credentials = {
    'host': 'mysql-30c37a4d-projectx.a.aivencloud.com',
    'port': 13625,
    'user': 'avnadmin',
    'password': 'AVNS_og4Acl6XOMIp2M3NyB2',
    'db': 'defaultdb',
    'ssl': {'sslmode': 'REQUIRED'}
}

# SQLAlchemy setup
DATABASE_URL = f"mysql+pymysql://{db_credentials['user']}:{db_credentials['password']}@{db_credentials['host']}:{db_credentials['port']}/{db_credentials['db']}"
engine = create_engine(DATABASE_URL)
Base = declarative_base()

# Create a table class using SQLAlchemy ORM
class UserData(Base):
    __tablename__ = 'user_data'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True)
    email = Column(String(255), index=True)
    address = Column(String(255))
    position = Column(String(255))

# Create the table
metadata = MetaData()
user_data_table = Table('user_data', metadata,
                       Column('id', Integer, primary_key=True, index=True),
                       Column('name', String(255), index=True),
                       Column('email', String(255), index=True),
                       Column('address', String(255)),
                       Column('position', String(255)),
                       )

metadata.create_all(bind=engine)

# Dependency to get the database session

def get_db():
    db = Session(engine)
    try:
        yield db
    finally:
        db.close()

# Import the HTML templates
upload_form_template = open("upload_form_template.html").read()
search_form_template = open("search_form_template.html").read()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return HTMLResponse(content=upload_form_template, status_code=200)

@app.post("/submit")
async def submit(
    name: str = Form(...),
    email: str = Form(...),
    address: str = Form(...),
    position: str = Form(...),
    db: Session = Depends(get_db)
):
    # Use ORM to insert data into the database
    user_data = UserData(name=name, email=email, address=address, position=position)
    db.add(user_data)
    db.commit()

    return {"message": "Data submitted successfully."}

@app.get("/search", response_class=HTMLResponse)
async def search_form(request: Request):
    return HTMLResponse(content=search_form_template, status_code=200)

@app.post("/search")
async def search(
    search_name: str = Form(...),
    db: Session = Depends(get_db)
):
    # Use ORM to search for data in the database
    result = db.query(UserData).filter(UserData.name == search_name).all()

    return {"search_result": result}
