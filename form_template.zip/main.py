from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table
from sqlalchemy.orm import declarative_base, Session
import uvicorn

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Aiven Cloud MySQL credentials
db_credentials = {
    'host': 'mysql-30c37a4d-projectx.a.aivencloud.com',
    'port': 13625,
    'user': 'avnadmin',
    'password': 'AVNS_og4Acl6XOMIp2M3NyB2',
    'db': 'defaultdb',
    'ssl': {'sslmode': 'REQUIRED'}
}

# SQLAlchemy setup
DATABASE_URL = f"mysql+pymysql://{db_credentials['user']}:{db_credentials['password']}@{db_credentials['host']}:{db_credentials['port']}/{db_credentials['db']}"
engine = create_engine(DATABASE_URL)
Base = declarative_base()




# Create a table class using SQLAlchemy ORM
class UserData(Base):
    __tablename__ = 'user_data'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True)
    email = Column(String(255), index=True)
    address = Column(String(255))
    position = Column(String(255))

# Create the table
metadata = MetaData()
user_data_table = Table('user_data', metadata,
                       Column('id', Integer, primary_key=True, index=True),
                       Column('name', String(255), index=True),
                       Column('email', String(255), index=True),
                       Column('address', String(255)),
                       Column('position', String(255)),
                       )

metadata.create_all(bind=engine)

# Dependency to get the database session
def get_db():
    db = Session(engine)
    try:
        yield db
    finally:
        db.close()


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("upload_form_template.html", {"request": request})

@app.post("/submit")
async def submit(
    name: str = Form(...),
    email: str = Form(...),
    address: str = Form(...),
    position: str = Form(...),
    db: Session = Depends(get_db)
):
    user_data = UserData(name=name, email=email, address=address, position=position)
    db.add(user_data)
    db.commit()

    return {"message": "Data submitted successfully."}


@app.get("/search", response_class=HTMLResponse)
async def search_form(request: Request):
    return templates.TemplateResponse("search_form_template.html", {"request": request})

@app.post("/search")
async def search(
    search_name: str = Form(...),
    db: Session = Depends(get_db)
):
    result = db.query(UserData).filter(UserData.name == search_name).all()
    return {"search_result": result}

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8000)